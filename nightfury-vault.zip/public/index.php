<form action="upload.php" method="POST" enctype="multipart/form-data">
  <input type="file" name="file" accept=".jpg,.png">
  <button type="submit">Upload</button>
</form>